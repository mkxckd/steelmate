'use strict';

/** @type {ModdedBattleScriptsData} */
let BattleScripts = {
	gen: 7,
};

exports.BattleScripts = BattleScripts;
