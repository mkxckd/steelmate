'use strict';

/** @type {ModdedBattleScriptsData} */
let BattleScripts = {
	inherit: 'gen7',
	gen: 6,
};

exports.BattleScripts = BattleScripts;
