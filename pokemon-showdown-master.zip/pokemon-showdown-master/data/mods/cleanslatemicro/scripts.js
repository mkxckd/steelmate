'use strict';

/** @type {ModdedBattleScriptsData} */
let BattleScripts = {
	inherit: 'gen7',
};

exports.BattleScripts = BattleScripts;
