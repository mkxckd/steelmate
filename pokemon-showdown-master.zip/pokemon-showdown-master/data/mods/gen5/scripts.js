'use strict';

/**@type {ModdedBattleScriptsData} */
let BattleScripts = {
	inherit: 'gen6',
	gen: 5,
};

exports.BattleScripts = BattleScripts;
